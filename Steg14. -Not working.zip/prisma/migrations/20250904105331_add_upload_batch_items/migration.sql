-- CreateTable
CREATE TABLE "Upload" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "filename" TEXT NOT NULL,
    "totalRows" INTEGER NOT NULL,
    "metaJson" JSONB
);

-- CreateTable
CREATE TABLE "Product" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "uploadId" TEXT NOT NULL,
    "sourceKey" TEXT NOT NULL,
    "name_sv" TEXT,
    "description_sv" TEXT,
    "brand" TEXT,
    "attributes" JSONB,
    "optimizeDone" BOOLEAN NOT NULL DEFAULT false,
    "optimizedSvAt" DATETIME,
    "reservedBatchId" TEXT,
    CONSTRAINT "Product_reservedBatchId_fkey" FOREIGN KEY ("reservedBatchId") REFERENCES "ProductBatch" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "Product_uploadId_fkey" FOREIGN KEY ("uploadId") REFERENCES "Upload" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "ProductBatch" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "uploadId" TEXT NOT NULL,
    "status" TEXT NOT NULL,
    "idempotencyKey" TEXT,
    CONSTRAINT "ProductBatch_uploadId_fkey" FOREIGN KEY ("uploadId") REFERENCES "Upload" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "BatchItem" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "batchId" TEXT NOT NULL,
    "productId" TEXT NOT NULL,
    "step" TEXT NOT NULL,
    "status" TEXT NOT NULL,
    "errorMessage" TEXT,
    "startedAt" DATETIME,
    "finishedAt" DATETIME,
    CONSTRAINT "BatchItem_batchId_fkey" FOREIGN KEY ("batchId") REFERENCES "ProductBatch" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "BatchItem_productId_fkey" FOREIGN KEY ("productId") REFERENCES "Product" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateIndex
CREATE INDEX "Product_uploadId_optimizeDone_idx" ON "Product"("uploadId", "optimizeDone");

-- CreateIndex
CREATE INDEX "Product_uploadId_reservedBatchId_idx" ON "Product"("uploadId", "reservedBatchId");

-- CreateIndex
CREATE UNIQUE INDEX "Product_uploadId_sourceKey_key" ON "Product"("uploadId", "sourceKey");

-- CreateIndex
CREATE INDEX "ProductBatch_uploadId_idx" ON "ProductBatch"("uploadId");

-- CreateIndex
CREATE INDEX "ProductBatch_status_idx" ON "ProductBatch"("status");

-- CreateIndex
CREATE UNIQUE INDEX "BatchItem_batchId_productId_step_key" ON "BatchItem"("batchId", "productId", "step");
