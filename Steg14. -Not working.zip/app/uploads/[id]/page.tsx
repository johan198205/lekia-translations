'use client'

import { useState, useEffect } from 'react'
import { useParams } from 'next/navigation'

interface RemainingData {
  remainingCount: number
}

export default function UploadDetailsPage() {
  const params = useParams()
  const uploadId = params.id as string
  const [remainingCount, setRemainingCount] = useState<number>(0)
  const [loading, setLoading] = useState<boolean>(true)
  const [error, setError] = useState<string>('')

  useEffect(() => {
    const fetchRemainingCount = async () => {
      if (!uploadId) return
      
      try {
        setLoading(true)
        const response = await fetch(`/api/uploads/${uploadId}/remaining`)
        
        if (response.ok) {
          const data: RemainingData = await response.json()
          setRemainingCount(data.remainingCount)
        } else {
          setError('Kunde inte hämta remaining count')
        }
      } catch (err) {
        setError('Nätverksfel vid hämtning av remaining count')
      } finally {
        setLoading(false)
      }
    }

    fetchRemainingCount()
  }, [uploadId])

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-4">
          <div className="bg-white rounded-lg shadow-md p-6">
            <p className="text-gray-600">Laddar...</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <h1 className="text-3xl font-bold text-gray-900 mb-8 text-center">
          Upload Detaljer
        </h1>

        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">Upload Information</h2>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-gray-50 rounded-lg">
                <h3 className="font-medium text-gray-700 mb-2">Upload ID</h3>
                <p className="text-sm text-gray-600 font-mono">{uploadId}</p>
              </div>
              
              <div className="p-4 bg-gray-50 rounded-lg">
                <h3 className="font-medium text-gray-700 mb-2">Remaining Products</h3>
                {error ? (
                  <p className="text-sm text-red-600">{error}</p>
                ) : (
                  <p className="text-2xl font-bold text-blue-600">{remainingCount}</p>
                )}
              </div>
            </div>
            
            {error && (
              <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-sm text-red-600">
                  <strong>Fel:</strong> {error}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
