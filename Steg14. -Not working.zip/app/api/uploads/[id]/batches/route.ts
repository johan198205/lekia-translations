import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

const createBatchSchema = z.object({
  limit: z.number().int().positive(),
  idempotencyKey: z.string().optional()
})

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { limit, idempotencyKey } = createBatchSchema.parse(body)

    // Check if batch with same idempotencyKey already exists
    if (idempotencyKey) {
      const existingBatch = await prisma.productBatch.findFirst({
        where: {
          uploadId: id,
          idempotencyKey
        }
      })

      if (existingBatch) {
        // Get productIds for this batch
        const products = await prisma.product.findMany({
          where: {
            reservedBatchId: existingBatch.id
          },
          select: {
            id: true
          }
        })

        return NextResponse.json({
          batch: existingBatch,
          productIds: products.map(p => p.id)
        })
      }
    }

    // Create new batch in transaction
    const result = await prisma.$transaction(async (tx) => {
      // Create batch
      const batch = await tx.productBatch.create({
        data: {
          uploadId: id,
          status: 'pending',
          idempotencyKey
        }
      })

      // Get available products with deterministic ordering
      const products = await tx.product.findMany({
        where: {
          uploadId: id,
          optimizeDone: false,
          reservedBatchId: null
        },
        orderBy: [
          { createdAt: 'asc' },
          { id: 'asc' }
        ],
        take: limit,
        select: {
          id: true
        }
      })

      if (products.length === 0) {
        throw new Error('NoRemaining')
      }

      const productIds = products.map(p => p.id)

      // Reserve products for this batch
      await tx.product.updateMany({
        where: {
          id: { in: productIds }
        },
        data: {
          reservedBatchId: batch.id
        }
      })

      // Create batch items
      await tx.batchItem.createMany({
        data: productIds.map(productId => ({
          batchId: batch.id,
          productId,
          step: 'optimize',
          status: 'pending'
        }))
      })

      // Update batch status to running
      const updatedBatch = await tx.productBatch.update({
        where: { id: batch.id },
        data: { status: 'running' }
      })

      return { batch: updatedBatch, productIds }
    })

    return NextResponse.json(result)

  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid request data', details: error.issues },
        { status: 400 }
      )
    }

    if (error instanceof Error && error.message === 'NoRemaining') {
      return NextResponse.json(
        { error: 'NoRemaining' },
        { status: 409 }
      )
    }

    console.error('Create batch error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
