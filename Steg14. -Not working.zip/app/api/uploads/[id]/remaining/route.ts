import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export const runtime = 'nodejs';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    if (!id) {
      return NextResponse.json(
        { error: 'Upload ID is required' },
        { status: 400 }
      )
    }

    const remainingCount = await prisma.product.count({
      where: {
        uploadId: id,
        optimizeDone: false,
        reservedBatchId: null
      }
    })

    return NextResponse.json({ remainingCount })
  } catch (error) {
    console.error('Get remaining count error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
