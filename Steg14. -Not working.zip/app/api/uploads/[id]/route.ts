import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: uploadId } = await params;

    // Fetch upload with products
    const upload = await prisma.upload.findUnique({
      where: { id: uploadId },
      include: {
        products: {
          orderBy: { createdAt: 'asc' }
        }
      }
    });

    if (!upload) {
      return NextResponse.json(
        { error: 'Upload not found' },
        { status: 404 }
      );
    }

    // Transform products to match frontend expectations
    const products = upload.products.map(product => ({
      name_sv: product.name_sv,
      description_sv: product.description_sv,
      attributes: product.attributes,
      tone_hint: product.attributes?.tone_hint,
      optimized_sv: product.optimizedSvAt ? 'Optimized' : undefined,
      status: product.optimizeDone ? 'optimized' : 'pending'
    }));

    return NextResponse.json({
      id: upload.id,
      filename: upload.filename,
      totalRows: upload.totalRows,
      products
    });
  } catch (error) {
    console.error('Error fetching upload:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
