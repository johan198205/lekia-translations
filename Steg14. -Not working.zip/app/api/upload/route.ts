import { NextRequest, NextResponse } from 'next/server';
import { normalize, NormalizationError } from '@/lib/excel/normalize';
import { prisma } from '@/lib/prisma';
import { createHash } from 'crypto';

const MAX_FILE_SIZE = 16 * 1024 * 1024; // 16 MB
const ALLOWED_MIME_TYPES = [
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'application/octet-stream', // Some systems send this for .xlsx
];

function generateSourceKey(product: any): string {
  // Try to find SKU/article number fields first
  const skuFields = ['sku', 'SKU', 'articleNumber', 'article_number', 'id', 'product_id'];
  
  for (const field of skuFields) {
    if (product[field] && String(product[field]).trim()) {
      return String(product[field]).trim().toLowerCase();
    }
  }
  
  // If no SKU found, create stable hash from identifying fields
  const hashInput = [
    product.name_sv || '',
    product.brand || '',
    product.attributes || ''
  ].join('|');
  
  return createHash('sha256').update(hashInput).digest('hex').substring(0, 16);
}

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File | null;

    if (!file) {
      return NextResponse.json(
        { error: 'No file provided' },
        { status: 400 }
      );
    }

    // Validate file extension
    if (!file.name.toLowerCase().endsWith('.xlsx')) {
      return NextResponse.json(
        { error: 'Invalid file type' },
        { status: 400 }
      );
    }

    // Validate MIME type
    if (!ALLOWED_MIME_TYPES.includes(file.type)) {
      return NextResponse.json(
        { error: 'Invalid file type' },
        { status: 400 }
      );
    }

    // Validate file size
    if (file.size > MAX_FILE_SIZE) {
      return NextResponse.json(
        { error: 'File too large' },
        { status: 413 }
      );
    }

    // Read file buffer
    const buffer = Buffer.from(await file.arrayBuffer());

    // Normalize Excel data
    const result = await normalize(buffer);

    // Validate rows is array
    if (!Array.isArray(result.products)) {
      return NextResponse.json(
        { error: 'Invalid data format' },
        { status: 400 }
      );
    }

    const totalRows = result.products.length;

    // Create Upload record
    const upload = await prisma.upload.create({
      data: {
        filename: file.name,
        totalRows,
        metaJson: result.meta
      }
    });

    // Process products with idempotent upsert
    for (const product of result.products) {
      const sourceKey = generateSourceKey(product);
      
      await prisma.product.upsert({
        where: {
          uploadId_sourceKey: {
            uploadId: upload.id,
            sourceKey
          }
        },
        create: {
          uploadId: upload.id,
          sourceKey,
          name_sv: product.name_sv,
          description_sv: product.description_sv,
          attributes: product.attributes
        },
        update: {
          name_sv: product.name_sv,
          description_sv: product.description_sv,
          attributes: product.attributes
        }
      });
    }

    console.log(`[UPLOAD] Created upload ${upload.id} with ${totalRows} products`);

    return NextResponse.json({
      id: upload.id,
      totalRows: upload.totalRows
    });
  } catch (error) {
    if (error instanceof NormalizationError) {
      if (error.message.includes('Missing required columns')) {
        return NextResponse.json(
          { error: error.message },
          { status: 400 }
        );
      }
      if (error.message.includes('Invalid workbook')) {
        return NextResponse.json(
          { error: 'Invalid workbook' },
          { status: 400 }
        );
      }
    }

    console.error('Upload error:', error);
    console.error('Error stack:', error instanceof Error ? error.stack : 'No stack trace');
    return NextResponse.json(
      { error: 'Internal server error', details: error instanceof Error ? error.message : String(error) },
      { status: 500 }
    );
  }
}
