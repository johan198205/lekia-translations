import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

const createBatchSchema = z.object({
  uploadId: z.string().min(1),
  selectedIndices: z.array(z.number()).min(1)
})

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { uploadId, selectedIndices } = createBatchSchema.parse(body)

    // Create batch
    const batch = await prisma.productBatch.create({
      data: {
        uploadId: uploadId,
        status: 'pending'
      }
    })

    // Get products from upload
    const products = await prisma.product.findMany({
      where: { uploadId: uploadId },
      orderBy: { createdAt: 'asc' }
    })

    // Create batch items for selected products
    const batchItems = selectedIndices.map(index => {
      const product = products[index]
      if (!product) return null
      
      return {
        batchId: batch.id,
        productId: product.id,
        step: 'optimize' as const,
        status: 'pending' as const
      }
    }).filter(Boolean)

    // Create batch items
    if (batchItems.length > 0) {
      await prisma.batchItem.createMany({
        data: batchItems
      })
    }

    return NextResponse.json({
      id: batch.id,
      uploadId: batch.uploadId,
      status: batch.status,
      itemCount: batchItems.length
    })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid request data', details: error.issues },
        { status: 400 }
      )
    }

    console.error('Create batch error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function GET() {
  try {
    const batches = await prisma.productBatch.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        reservedProducts: {
          select: {
            id: true,
            optimizeDone: true
          }
        }
      }
    })

    return NextResponse.json(batches)
  } catch (error) {
    console.error('Get batches error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
