import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export const runtime = 'nodejs';

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: batchId } = await params

    // Verify batch exists
    const batch = await prisma.productBatch.findUnique({
      where: { id: batchId }
    })

    if (!batch) {
      return NextResponse.json(
        { error: 'Batch not found' },
        { status: 404 }
      )
    }

    // Run transaction to cancel batch
    const updatedBatch = await prisma.$transaction(async (tx) => {
      // a) Set ProductBatch.status = 'canceled'
      const updatedBatch = await tx.productBatch.update({
        where: { id: batchId },
        data: { status: 'canceled' }
      })

      // b) Reset reservedBatchId on all Products that belong to this batch
      await tx.product.updateMany({
        where: { reservedBatchId: batchId },
        data: { reservedBatchId: null }
      })

      // c) Set BatchItem.status = 'canceled' where batchId=[id] and status='pending'
      await tx.batchItem.updateMany({
        where: { 
          batchId: batchId,
          status: 'pending'
        },
        data: { status: 'canceled' }
      })

      return updatedBatch
    })

    return NextResponse.json({ batch: updatedBatch })
  } catch (error) {
    console.error('Cancel batch error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
