import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { optimizeSv } from '@/lib/llm/adapter'

export const runtime = 'nodejs';

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: batchId } = await params
    
    // Get prompt settings from client
    const body = await request.json().catch(() => ({}))
    const clientPromptSettings = body.clientPromptSettings || {}
    
    console.log('[OPTIMIZE] Received body:', JSON.stringify(body, null, 2));

    // Verify batch exists
    const batch = await prisma.productBatch.findUnique({
      where: { id: batchId }
    })

    if (!batch) {
      return NextResponse.json(
        { error: 'Batch not found' },
        { status: 404 }
      )
    }

    console.log(`[OPTIMIZE] Batch found: ${batch.id}`);

    // Get pending BatchItems for this batch in deterministic order
    const pendingItems = await prisma.batchItem.findMany({
      where: { 
        batchId,
        step: 'optimize',
        status: 'pending'
      },
      orderBy: [
        { id: 'asc' }
      ],
      include: { product: true }
    })

    console.log(`[OPTIMIZE] Found ${pendingItems.length} pending items to process`);

    let processed = 0;
    let errors = 0;

    // Process each item sequentially
    for (const item of pendingItems) {
      try {
        console.log(`[OPTIMIZE] Processing item: ${item.id} for product: ${item.product.name_sv}`);
        
        // Set startedAt
        await prisma.batchItem.update({
          where: { id: item.id },
          data: { startedAt: new Date() }
        })
        
        // Use LLM adapter for optimization with client prompt settings
        const optimizedText = await optimizeSv({
          nameSv: item.product.name_sv || '',
          descriptionSv: item.product.description_sv || '',
          attributes: item.product.attributes as string | object | null,
          toneHint: undefined // tone_hint field not in schema
        }, clientPromptSettings.optimize)
        
        console.log(`[OPTIMIZE] Product ${item.product.name_sv} optimized successfully, length: ${optimizedText.length}`);
        
        // Update Product: optimizeDone=true, optimizedSvAt=now()
        await prisma.product.update({
          where: { id: item.productId },
          data: {
            optimizeDone: true,
            optimizedSvAt: new Date()
          }
        })
        
        // Set BatchItem.status='done', finishedAt=now()
        await prisma.batchItem.update({
          where: { id: item.id },
          data: {
            status: 'done',
            finishedAt: new Date()
          }
        })
        
        processed++;
        console.log(`[OPTIMIZE] Item ${item.id} completed successfully`)
        
      } catch (error) {
        console.error(`[OPTIMIZE] Error optimizing item ${item.id}:`, error)
        
        // Set BatchItem.status='error', errorMessage=<string>, finishedAt=now()
        await prisma.batchItem.update({
          where: { id: item.id },
          data: {
            status: 'error',
            errorMessage: error instanceof Error ? error.message : 'Optimization failed',
            finishedAt: new Date()
          }
        })
        
        errors++;
        console.log(`[OPTIMIZE] Item ${item.id} failed with error`)
      }
    }

    // Check if any items are still pending for this batch
    const remainingPendingItems = await prisma.batchItem.count({
      where: { 
        batchId,
        step: 'optimize',
        status: 'pending'
      }
    })

    // If no pending items remain, set ProductBatch.status='completed'
    if (remainingPendingItems === 0) {
      await prisma.productBatch.update({
        where: { id: batchId },
        data: { status: 'completed' }
      })
      console.log(`[OPTIMIZE] Batch ${batchId} marked as completed`)
    }

    return NextResponse.json({
      processed,
      errors
    })
  } catch (error) {
    console.error('Optimize error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
