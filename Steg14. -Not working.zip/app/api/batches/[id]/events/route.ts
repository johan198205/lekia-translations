import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'

export const runtime = 'nodejs';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: batchId } = await params

    // Verify batch exists
    const batch = await prisma.productBatch.findUnique({
      where: { id: batchId }
    })

    if (!batch) {
      return new Response('Batch not found', { status: 404 })
    }

    // Create SSE stream
    const stream = new ReadableStream({
      start(controller) {
        const encoder = new TextEncoder()
        const client = prisma as any
        
        const sendEvent = (data: any) => {
          const eventData = `data: ${JSON.stringify(data)}\n\n`
          controller.enqueue(encoder.encode(eventData))
        }

        const pollInterval = setInterval(async () => {
          try {
            // Get current batch status
            const currentBatch = await prisma.productBatch.findUnique({
              where: { id: batchId },
              select: { status: true }
            })

            if (!currentBatch) {
              clearInterval(pollInterval)
              controller.close()
              return
            }

            // Get counts for BatchItem per status (explicit to avoid TS typing quirks)
            const [pendingCount, doneCount, errorCount, canceledCount] = await Promise.all([
              client.batchItem.count({ where: { batchId, status: 'pending' } }),
              client.batchItem.count({ where: { batchId, status: 'done' } }),
              client.batchItem.count({ where: { batchId, status: 'error' } }),
              client.batchItem.count({ where: { batchId, status: 'canceled' } })
            ])

            const statusCounts = {
              pending: pendingCount,
              done: doneCount,
              error: errorCount,
              canceled: canceledCount
            }

            const total = statusCounts.pending + statusCounts.done + statusCounts.error + statusCounts.canceled
            const percent = total === 0 ? 0 : Math.round(((statusCounts.done + statusCounts.error) / total) * 100)

            const eventData = {
              type: 'progress',
              data: {
                status: currentBatch.status,
                counts: statusCounts,
                total,
                percent,
                done: statusCounts.done + statusCounts.error,
                timestamp: new Date().toISOString()
              }
            }

            sendEvent(eventData)

            // Close stream if batch is completed or canceled
            const batchStatus = currentBatch.status as unknown as string
            if (batchStatus === 'completed' || batchStatus === 'canceled') {
              // Send final event before closing
              const finalEventData = {
                type: 'end',
                data: {
                  status: batchStatus,
                  counts: statusCounts,
                  total,
                  percent,
                  done: statusCounts.done + statusCounts.error,
                  timestamp: new Date().toISOString()
                }
              }
              sendEvent(finalEventData)
              
              clearInterval(pollInterval)
              controller.close()
            }
          } catch (error) {
            console.error('SSE polling error:', error)
            clearInterval(pollInterval)
            controller.close()
          }
        }, 1000)

        // Handle client disconnect
        request.signal.addEventListener('abort', () => {
          clearInterval(pollInterval)
          controller.close()
        })
      }
    })

    return new Response(stream, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-store',
        'Connection': 'keep-alive'
      }
    })
  } catch (error) {
    console.error('SSE endpoint error:', error)
    return new Response('Internal server error', { status: 500 })
  }
}